skiboot-5.1.15
--------------

skiboot-5.1.15 was released on Wed March 16th, 2016.

skiboot-5.1.15 is the 16th stable release of 5.1, it follows skiboot-5.1.14
(which was released March 9th, 2016). This release contains one bug fix, a
fix for a memory leak in an error path for AMI BMC based systems when
logging non-severe errors. As such, it is a minor bug fix update.
