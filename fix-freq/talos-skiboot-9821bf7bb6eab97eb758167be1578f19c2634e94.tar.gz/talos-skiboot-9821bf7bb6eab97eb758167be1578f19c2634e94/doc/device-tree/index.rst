Device Tree
===========

Device Tree for OPAL. Please refer to Device Tree Spec.

.. toctree::
   :maxdepth: 1
   :glob:

   *
   ibm,powerpc-cpu-features/*

