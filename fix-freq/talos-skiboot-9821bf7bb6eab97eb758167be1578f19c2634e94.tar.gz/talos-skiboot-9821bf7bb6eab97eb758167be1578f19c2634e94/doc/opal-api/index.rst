.. _opal-api:

======================
OPAL API Documentation
======================

The OPAL API is the interface between an Operating System and OPAL.

.. toctree::
   :maxdepth: 1
   :glob:

   *

