OPAL_INVALID_CALL
=================

An OPAL call of ``-1`` will always return ``OPAL_PARAMETER``. It is always ivalid.

It exists purely for testing.
